#!/bin/sh

cp tcf-agent/tcf-agent /opt/zedboard/bin/
cp tcf-agent/lib* /usr/lib/

# Start the tcf-agent
/opt/zedboard/bin/tcf-agent -d -L- &


