Name: TCF-AGENT
Description: debugging, profiling, code patching and performing other device software development tasks. We limit our scope of usage to debugging embedded applications
on Xilinx Zynq target boards. Although it is possible to perform Linux Kernel debugging of kernel source code and .ko files but we are only supporting application debugging
with this release.

Steps:
1. Copy the tcf-agent.targ.gz to /mnt/emmc of Smartellite Terminal using secure copy or MobaXterm.
	secure copy:$scp tcf-agent.tar.gz root@192.168.0.1:/mnt/emmc/
2. untar tcf-agent.tar.gz
	$tar -xvzf /mnt/emmc/tcf-agent.tar.gz -C /mnt/emmc/
3. cd /mnt/emmc
4. ./tcf-agent/install.sh

The install script will also start the tcf-agent.


Note: Since the installation takes places in ram file system, we will need to run the install every time the smartellite reboots.
